#!/bin/bash
#SBATCH --job-name="rfm_NCCLallreduce_9da46141"
#SBATCH --ntasks=16
#SBATCH --ntasks-per-node=4
#SBATCH --cpus-per-task=32
#SBATCH --output=rfm_job.out
#SBATCH --error=rfm_job.err
#SBATCH --time=0:10:0
#SBATCH --nodes=4
#SBATCH -p gpu-h100s
#SBATCH -A hpcapps
#SBATCH --gres=gpu:4
#SBATCH --mem=0
module load gcc
module load cuda/13.2
source ~/.bashrc
echo "============================================================"
echo "ReFrame Universal Job Information"
echo "    Job ID     : $SLURM_JOB_ID"
echo "    Job name   : $SLURM_JOB_NAME"
echo "    Num. tasks : $SLURM_NTASKS"
echo "    Num. nodes : $SLURM_NNODES"
echo "    Nodelist   : $SLURM_JOB_NODELIST"
echo "============================================================"
ml gcc cuda/13.2 nccl mpich
ulimit -s unlimited
export PATH=/projects/esifapps/mselensk/nccl-tests/build:${PATH}
export NCCL_NET_GDR_LEVEL=PHB
srun --cpus-per-task=32  --ntasks-per-node=4 --nodes=4 --gres=gpu:4 all_reduce_perf -b 8 -e 4G -f 2 -d double

